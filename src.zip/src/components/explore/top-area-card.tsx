// src/components/explore/top-area-card.tsx - UPDATED to match your design
"use client";

import Link from "next/link";
import { Icon } from "@/components/icon";
import { TopArea } from "@/lib/analysis/types";

interface TopAreaCardProps {
    rank: number;
    area: TopArea;
    business: string; // ✅ NEW - for navigation
    location: string; // ✅ NEW - for navigation
}

export function TopAreaCard({
    rank,
    area,
    business,
    location,
}: TopAreaCardProps) {
    const getColor = (score: number) => {
        if (score >= 8)
            return { bg: "success", text: "success", icon: "trending_up" };
        if (score >= 6.5)
            return { bg: "warning", text: "warning", icon: "trending_up" };
        return { bg: "danger", text: "danger", icon: "trending_flat" };
    };

    const color = getColor(area.score);

    return (
        <div className="group flex flex-col gap-4 rounded-xl p-5 shadow-soft transition-all border border-border-light hover:border-primary/50 hover:shadow-lg">
            <div className="flex items-start justify-between gap-4">
                <h3 className="text-lg font-bold text-text-primary-light">
                    #{rank} – {area.name}
                </h3>
                <div
                    className={`flex items-center gap-2 rounded-full bg-${color.bg}/10 px-3 py-1 text-xs font-semibold text-${color.text} group-hover:scale-105 transition-transform`}
                >
                    <Icon name={color.icon} className="text-base" />
                    <span>{area.score.toFixed(1)} / 10</span>
                </div>
            </div>

            {/* ✅ FILLED BULLETS - Google Stitch exact */}
            <ul className="flex flex-col gap-2 pl-5 list-disc text-sm marker:text-text-primary-light">
                <li>
                    <span className="font-medium text-text-primary-light">
                        {area.saturation} saturation
                    </span>
                    : {area.competitors || 2} similar competitors
                </li>
                <li>
                    <span className="font-medium text-text-primary-light">
                        {area.fit} customer fit
                    </span>{" "}
                    with local demographics
                </li>
                <li className="font-medium text-text-primary-light">
                    {area.gaps?.[0] || "Strong price power"}
                </li>
                <li className="font-medium text-text-primary-light">
                    {area.gaps?.[1] || "Growing demand"}
                </li>
            </ul>

            <p className="text-xs text-text-secondary-light">
                Est. rent: {area.rent} • Foot traffic: {area.traffic}
            </p>

            {/* ✅ Link + Hover Effects */}
            <Link
                href={`/explore/${encodeURIComponent(
                    business
                )}/${encodeURIComponent(location)}/area/${encodeURIComponent(
                    area.name
                )}`}
                className="text-muted-foreground hover:text-primary cursor-pointer font-medium text-sm self-start transition-colors group-hover:translate-x-1"
            >
                View detailed analysis →
            </Link>
        </div>
    );
}
